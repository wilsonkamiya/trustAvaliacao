package br.com.avaliacao.factory;

import br.com.avaliacao.dao.AvaliacaoDAO;
import br.com.avaliacao.dao.impl.OracleAvaliacaoDAO;

public class DAOFactory {
	public static AvaliacaoDAO getAtividadeFisica() {
		return new OracleAvaliacaoDAO();
	};
}
