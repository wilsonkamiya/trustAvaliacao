package br.com.avaliacao.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.avaliacao.bean.risco;
import br.com.avaliacao.dao.impl.OracleAvaliacaoDAO;

@WebServlet("/RiscoServlet")
public class RiscoServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException{
		try {
	 		String nomeCliente  = req.getParameter("txt_nome");
			String limite 		= req.getParameter("nbr_limite");
			String tipoRisco    = req.getParameter("lst_risco");
			String pctAplicado  = req.getParameter("nbr_pctAplicado");
			
			System.out.println(nomeCliente);
			System.out.println(limite);
			System.out.println(tipoRisco);
			System.out.println(pctAplicado);
			risco r = new risco(nomeCliente, Float.valueOf(limite),tipoRisco, Float.valueOf(pctAplicado));
			OracleAvaliacaoDAO dao = new OracleAvaliacaoDAO();
			dao.cadastrar(r);
			req.setAttribute("sucessCAD", "Registro inserido com sucesso!");
			req.getRequestDispatcher("/trusthubAvaliacao.jsp").forward(req, res);
			
		}catch(ServletException e){
			e.printStackTrace();
			req.setAttribute("sucessCAD", "RiscoServlet com erro - ServletException, verificar! "+ e.getMessage());
		}catch(IOException e) {
			e.printStackTrace();
			req.setAttribute("sucessCAD", "RiscoServlet com erro - IOException, verificar! "+ e.getMessage());
		}catch(Exception e){
			e.printStackTrace();
			req.setAttribute("sucessCAD", "RiscoServlet com erro - Exception, verificar! " + e.getMessage());
		}
	}
}
