package br.com.avaliacao.bean;
 

public class risco {
	
	private int idRisco;
	private String nomeCliente; 
	private float limite;
	private String tipoRisco;
	private float pctAplicado;
	
	public risco() {};
	public risco(String nomeCliente, float limite, String tipoRisco, float pctAplicado) {
		this.nomeCliente=nomeCliente;
		this.limite=limite;
		this.tipoRisco=tipoRisco;
		this.pctAplicado=pctAplicado;
	}
	
	public risco(int idRisco, String nomeCliente, float limite, String tipoRisco, float pctAplicado) {
		this.idRisco = idRisco;
		this.nomeCliente=nomeCliente;
		this.limite=limite;
		this.tipoRisco=tipoRisco;
		this.pctAplicado=pctAplicado;
	}
	
	public int getIdRisco() {
		return idRisco;
	}
	public void setIdRisco(int idRisco) {
		this.idRisco = idRisco;
	}
	public String getNomeCliente() {
		return nomeCliente;
	}
	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}
	public float getLimite() {
		return limite;
	}
	public void setLimite(float limite) {
		this.limite = limite;
	}
	public String getTipoRisco() {
		return tipoRisco;
	}
	public void setTipoRisco(String tipoRisco) {
		this.tipoRisco = tipoRisco;
	}
	public float getPctAplicado() {
		return pctAplicado;
	}
	public void setPctAplicado(float pctAplicado) {
		this.pctAplicado = pctAplicado;
	};
	
}
