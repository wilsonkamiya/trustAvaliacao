package br.com.avaliacao.dao;

import java.util.List;

import br.com.avaliacao.bean.risco; 

public interface AvaliacaoDAO {
	void cadastrar(risco r);
	List<risco> listar();
	String listarJson();
}
