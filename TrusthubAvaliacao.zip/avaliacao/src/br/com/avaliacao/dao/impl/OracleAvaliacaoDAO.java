package br.com.avaliacao.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import br.com.avaliacao.bean.risco;
import br.com.avaliacao.dao.AvaliacaoDAO;
import br.com.avaliacao.singleton.ConnectionManager; 

public class OracleAvaliacaoDAO implements AvaliacaoDAO {
	private Connection conexao;
	
	@Override
	public void cadastrar(risco r) {
		// TODO Auto-generated method stub
		PreparedStatement stmt = null;
		try {
			conexao = ConnectionManager.getInstance().getConnection();
			String sql = "INSERT INTO RISCO(ID_RISCO,NM_CLIENTE,VL_LIMITE,TIPO_RISCO,PCT_APLICADO)"
					+ " VALUES(SQ_RISCO.NEXTVAL,?,?,?,?)";
			stmt = conexao.prepareStatement(sql);
			stmt.setString(1, r.getNomeCliente());
			stmt.setFloat(2, r.getLimite());
			stmt.setString(3, r.getTipoRisco());
			stmt.setFloat(4, r.getPctAplicado());
			stmt.executeUpdate();
		}catch (SQLException e) {
			e.printStackTrace();

		}finally {
			try {
				stmt.close();
				conexao.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public List<risco> listar() {
		// TODO Auto-generated method stub
		
		List<risco> lista = new ArrayList<risco>();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			conexao = ConnectionManager.getInstance().getConnection();
			stmt = conexao.prepareStatement("SELECT * FROM RISCO ORDER BY 1");
			rs = stmt.executeQuery();
			
			//percorre registros encontrados
			while(rs.next()) {
				int    idRisco     = rs.getInt("ID_RISCO");
				String nomeCliente = rs.getString("NM_CLIENTE");
				float  limite      = rs.getFloat("VL_LIMITE");
				String tipoRisco   = rs.getString("TIPO_RISCO");
				float  pctAplicado = rs.getFloat("PCT_APLICADO");
				
				risco r = new risco(idRisco, nomeCliente, limite,tipoRisco,pctAplicado);
				lista.add(r);
			}
			 
		}catch(SQLException e){
			e.printStackTrace();
			
		}finally {
			try {
				stmt.close();
				rs.close();
				conexao.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}			
		 
		return lista;
	}	
	
	//metodo para devolver string Json.
	@Override
	public String listarJson() {
		OracleAvaliacaoDAO dao = new OracleAvaliacaoDAO();
		String objJSON = new Gson().toJson(dao.listar());
		
		return objJSON;
	} 
	
}