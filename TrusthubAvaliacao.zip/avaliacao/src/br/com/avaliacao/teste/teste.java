package br.com.avaliacao.teste;
import java.util.List;

import com.google.gson.Gson;

import br.com.avaliacao.bean.risco;
import br.com.avaliacao.dao.impl.OracleAvaliacaoDAO;

public class teste {
	
	public static void main(String[] args) {
		OracleAvaliacaoDAO dao = new OracleAvaliacaoDAO();
		List<risco> r = dao.listar();
		String objeto = new Gson().toJson(r);
		System.out.println(objeto);
	}
}
